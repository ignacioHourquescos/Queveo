CREATE TABLE actor (	
      id INT NOT NULL auto_increment,
      nombre VARCHAR(70),
      PRIMARY KEY (id)
);