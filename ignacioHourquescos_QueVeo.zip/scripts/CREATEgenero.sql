CREATE TABLE genero (	
      id INT NOT NULL auto_increment,
	nombre VARCHAR(30) NOT NULL,
      PRIMARY KEY (id)
);
